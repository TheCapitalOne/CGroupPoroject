/*
 * Server.h
 *
 *  Created on: Mar 2, 2022
 *      Author: djc7941, znb34
 */

#ifndef SERVER_H_
#define SERVER_H_

// run server prototype
//		call to run the web server
int RunServer(int portnum);

#endif /* SERVER_H_ */
