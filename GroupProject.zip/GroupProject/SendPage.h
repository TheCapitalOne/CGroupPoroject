/*
 * SendPage.h
 *
 *  Created on: Mar 7, 2022
 *      Author: djc7941
 */

#ifndef SENDPAGE_H_
#define SENDPAGE_H_

//
int SendStatusPage();

//
int SendErrorPage();

#endif /* SENDPAGE_H_ */
