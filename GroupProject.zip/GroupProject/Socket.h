/*
 * Socket.h
 *
 *  Created on: Mar 9, 2022
 *      Author: djc7941, znb34
 */

#ifndef SOCKET_H_
#define SOCKET_H_

//run Open Socket prototype
int OpenSocket(int sockfd);

#endif /* SOCKET_H_ */
